package com.example.amigowalletTransfer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigowalletTransferApplicationTests {

	@Test
	void contextLoads() {
	}

}
