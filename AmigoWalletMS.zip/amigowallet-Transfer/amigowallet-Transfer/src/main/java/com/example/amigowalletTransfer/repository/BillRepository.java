package com.example.amigowalletTransfer.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.amigowalletTransfer.entity.Bill;

public interface BillRepository extends CrudRepository<Bill,String> {
   List<Bill> findByPhoneNo(Long phoneNo);
}

