package com.example.amigowalletTransfer.exception;

public class AmigoWalletException extends Exception {
	private static final long serialVersionUID = 1L;
	public AmigoWalletException(String message)
	{
		super(message);
	}

}
