package com.example.amigowalletTransfer.dto;


import java.time.LocalDateTime;
import lombok.Data;

@Data
public class TransactionDTO {
	private Integer transactionId;
	private LocalDateTime transactionDateTime;
	private Double amountTransferred;
	private String creditOrDebit;
	private String status;
	private Long phoneNo;
	private String type;
	private String description;
	private Long opponentNumber;
	public Integer getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}
	public LocalDateTime getTransactionDateTime() {
		return transactionDateTime;
	}
	public void setTransactionDateTime(LocalDateTime transactionDateTime) {
		this.transactionDateTime = transactionDateTime;
	}
	public Double getAmountTransferred() {
		return amountTransferred;
	}
	public void setAmountTransferred(Double amountTransferred) {
		this.amountTransferred = amountTransferred;
	}
	public String getCreditOrDebit() {
		return creditOrDebit;
	}
	public void setCreditOrDebit(String creditOrDebit) {
		this.creditOrDebit = creditOrDebit;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Long getOpponentNumber() {
		return opponentNumber;
	}
	public void setOpponentNumber(Long opponentNumber) {
		this.opponentNumber = opponentNumber;
	}
	
}