package com.example.amigowalletTransfer.service;

import java.util.List;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.amigowalletTransfer.dto.BankAccountDTO;
import com.example.amigowalletTransfer.dto.RegistrationDTO;
import com.example.amigowalletTransfer.dto.TransactionDTO;
import com.example.amigowalletTransfer.entity.Bill;
import com.example.amigowalletTransfer.exception.AmigoWalletException;
import com.example.amigowalletTransfer.repository.BankAccountRepository;
import com.example.amigowalletTransfer.repository.BillRepository;
@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

	//	@Autowired
	//	AccountRepository accountRepository;

	@Autowired
	BankAccountRepository bankAccountRepository;

	@Autowired
	BillRepository billRepository;

	@Autowired
	TransactionsList transactionsList;

	@Autowired
	ModelMapper modelMapper;

	// Transfer money from bank to wallet 
	@Override
	public Double selfTransferToWallet(RegistrationDTO account,Double amount) throws AmigoWalletException {
		//		if(Boolean.FALSE.equals(AmigoWalletServiceImpl.flag))
		//			throw new AmigoWalletException("SERVICE.Login_Needed");
		//	Registration account = accountRepository.findByBankAccountAccountNumber(accountNumber);
		TransactionDTO transactionDTO = new TransactionDTO();
		if(account == null)
			throw new AmigoWalletException("SERVICE.BankAccountNumber.NotFound");
		BankAccountDTO bankAccount = account.getBankAccountDTO();
		if(bankAccount.getBalance()<amount)
		{
			transactionDTO.setAmountTransferred(amount);
			transactionDTO.setPhoneNo(account.getPhoneNo());
			transactionDTO.setType("Self Transfer");
			transactionDTO.setDescription("From Bank to Wallet");
			transactionDTO.setOpponentNumber(account.getPhoneNo());
			transactionsList.transactionsFailed(transactionDTO);
			throw new AmigoWalletException("SERVICE.Insufficient_Balance");
		}
		//debit details
		bankAccount.setBalance(bankAccount.getBalance()-amount);
		account.setWalletAmount(account.getWalletAmount()+amount);
		transactionDTO.setAmountTransferred(amount);
		transactionDTO.setPhoneNo(account.getPhoneNo());
		transactionDTO.setOpponentNumber(account.getPhoneNo());
		transactionDTO.setType("Self Transfer");
		transactionDTO.setDescription("From Bank to Wallet");
		transactionsList.transactionsDebit(transactionDTO);
		//Credit
		//transactionDTO.setAmountTransferred(amount);
	//	transactionDTO.setPhoneNo(account.getPhoneNo());
		//transactionDTO.setType("Self Transfer");
		//transactionDTO.setDescription("From Bank to Wallet");
		transactionsList.transactionsCredit(transactionDTO);
		transactionsList.updateRegistration(account);
		return bankAccount.getBalance();
	}

	// US 1 - Self transfer from wallet to bank
	@Override
	public Double selfTransferFromWallet(RegistrationDTO account,Double amount) throws AmigoWalletException {
		//		if(Boolean.FALSE.equals(AmigoWalletServiceImpl.flag))
		//			throw new AmigoWalletException("SERVICE.Login_Needed");
		//	Optional<Registration> optional = accountRepository.findById(accountDTO.getSenderPhoneNo());
		TransactionDTO transactionDTO = new TransactionDTO();
		//	Registration account = optional.orElseThrow(()->new AmigoWalletException("SERVICE.Account.PhoneNo_NotFound"));
		if(((account.getWalletAmount())<(amount) || account.getWalletAmount()==0))
		{
			//accountDTO.setName(account.getName());
			transactionDTO.setAmountTransferred(amount);
			transactionDTO.setPhoneNo(account.getPhoneNo());
			transactionDTO.setOpponentNumber(account.getPhoneNo());
			transactionDTO.setType("Self Transfer");
			transactionDTO.setDescription("From Wallet to Bank");
			transactionsList.transactionsFailed(transactionDTO);
			throw new AmigoWalletException("SERVICE.Insufficient_Balance");
		}
		account.getBankAccountDTO().setBalance(((account.getBankAccountDTO().getBalance())+amount));
		account.setWalletAmount((account.getWalletAmount())-(amount));
		//debit
		transactionDTO.setAmountTransferred(amount);
		transactionDTO.setPhoneNo(account.getPhoneNo());
		transactionDTO.setOpponentNumber(account.getPhoneNo());
		transactionDTO.setType("Self Transfer");
		transactionDTO.setDescription("From Wallet to Bank");
		transactionsList.transactionsDebit(transactionDTO);
		//Credit
		//transactionDTO.setAmountTransferred(amount);
		//transactionDTO.setPhoneNo(account.getPhoneNo());
		//transactionDTO.setType("Self Transfer");
		//transactionDTO.setDescription("From Wallet to Bank");
		transactionsList.transactionsCredit(transactionDTO);
		transactionsList.updateRegistration(account);
		return account.getWalletAmount();
	}

	//US-2 Transfer money from wallet to another wallet
	@Override
	public Double moneyTransferToAnotherWallet(RegistrationDTO sender, RegistrationDTO receiver,Double amount) throws AmigoWalletException {
		//		if(Boolean.FALSE.equals(AmigoWalletServiceImpl.flag))
		//			throw new AmigoWalletException("SERVICE.Login_Needed");
		if((sender.getPhoneNo()).equals(receiver.getPhoneNo()))
			throw new AmigoWalletException("SERVICE.Trying_To_Do_Self_Transfer");
		//		Optional<Registration> senderOptional = accountRepository.findById(accountDTO.getSenderPhoneNo());
		//		Optional<Registration> receiverOptional = accountRepository.findById(accountDTO.getPhoneNo());
		//		Registration sender = senderOptional.orElseThrow(()->new AmigoWalletException("SERVICE.Sender_Or_Receiver_Details_NotFound"));
		//		Registration receiver = receiverOptional.orElseThrow(()->new AmigoWalletException("SERVICE.Sender_Or_Receiver_Details_NotFound"));
		TransactionDTO transactionDTO = new TransactionDTO();
		if(sender.getWalletAmount()<amount)
		{
			transactionDTO.setAmountTransferred(amount);
			transactionDTO.setPhoneNo(sender.getPhoneNo());
			transactionDTO.setOpponentNumber(receiver.getPhoneNo());
			transactionDTO.setType("Wallet Transfer");
			transactionDTO.setDescription("From Wallet to Wallet");
			transactionsList.transactionsFailed(transactionDTO);
			throw new AmigoWalletException("SERVICE.Insufficient_Balance");
		}
		sender.setWalletAmount(((sender.getWalletAmount())-(amount)));
		receiver.setWalletAmount(((receiver.getWalletAmount())+(amount)));
		//debit
		transactionDTO.setAmountTransferred(amount);
		transactionDTO.setPhoneNo(sender.getPhoneNo());
		transactionDTO.setType("Wallet Transfer");
		transactionDTO.setOpponentNumber(receiver.getPhoneNo());
		transactionDTO.setDescription("From Wallet to Wallet");
		transactionsList.transactionsDebit(transactionDTO);
		//Credit
		//transactionDTO.setAmountTransferred(amount);
		transactionDTO.setPhoneNo(receiver.getPhoneNo());
		transactionDTO.setOpponentNumber(sender.getPhoneNo());
		transactionDTO.setType("Wallet Transfer");
		transactionDTO.setDescription("From Wallet to Wallet");
		transactionsList.transactionsCredit(transactionDTO);
		transactionsList.updateRegistration(receiver);
		transactionsList.updateRegistration(sender);
		return sender.getWalletAmount();
	}

	//US-3 Pay Bills
	@Override
	public Double billPayment(RegistrationDTO account) throws AmigoWalletException {
		List<Bill> bills = billRepository.findByPhoneNo(account.getPhoneNo());
		Double totalAmount=0.0;
		if(bills.isEmpty())
			throw new AmigoWalletException("SERVICE.No_Bills_Found");
		//		Optional<Registration> optional = accountRepository.findById(phoneNo);
		//		AccountDTO accountDTO = new AccountDTO();
		//		Registration account = optional.orElseThrow(()->new AmigoWalletException("SERVICE.Account.PhoneNo_NotFound"));
		totalAmount = bills.stream().mapToDouble(Bill::getBillAmount).sum();
		TransactionDTO transactionDTO = new TransactionDTO();
		for(Bill b:bills)
		{
			if(account.getWalletAmount()<b.getBillAmount())
			{
				transactionDTO.setAmountTransferred(b.getBillAmount());
				transactionDTO.setPhoneNo(account.getPhoneNo());
				transactionDTO.setOpponentNumber(b.getPhoneNo());
				transactionDTO.setType("Bill Payment");
				transactionDTO.setDescription("From Wallet to Merchant");
				transactionsList.transactionsFailed(transactionDTO);
				throw new AmigoWalletException("SERVICE.Insufficient_Balance");
			}
			account.setWalletAmount(account.getWalletAmount()-b.getBillAmount());
			//debit
			transactionDTO.setAmountTransferred(b.getBillAmount());
			transactionDTO.setPhoneNo(account.getPhoneNo());
			transactionDTO.setOpponentNumber(b.getPhoneNo());
			transactionDTO.setType("Bill Payment");
			transactionDTO.setDescription("From Wallet to Merchant");
			transactionsList.transactionsDebit(transactionDTO);
			//Credit
			transactionDTO.setAmountTransferred(b.getBillAmount());
			transactionDTO.setPhoneNo(b.getPhoneNo());
			transactionDTO.setType("Bill Payment");
			transactionDTO.setOpponentNumber(account.getPhoneNo());
			transactionDTO.setDescription("From Wallet to Merchant");
			transactionsList.transactionsCredit(transactionDTO);
		}
		transactionsList.updateRegistration(account);
		return totalAmount;
	}	
}