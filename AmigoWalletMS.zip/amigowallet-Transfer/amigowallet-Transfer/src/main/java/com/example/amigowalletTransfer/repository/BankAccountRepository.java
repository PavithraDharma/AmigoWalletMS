package com.example.amigowalletTransfer.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.amigowalletTransfer.entity.BankAccount;


public interface BankAccountRepository extends CrudRepository<BankAccount, Long>{

}