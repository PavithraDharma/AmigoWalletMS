package com.example.amigowalletTransfer.dto;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RegistrationDTO {
	@NotNull(message="{RegistrationDTO.PhoneNo.Empty}")
    private Long phoneNo;
	@NotNull(message="{RegistrationDTO.Name.Empty}")
	@Pattern(regexp = "([A-Z][a-z]+)",message="{RegistrationDTO.Name.Invalid}")
	private String name;
	@NotNull(message="{RegistrationDTO.Empty_Field}")
	@Pattern(regexp = "([\\w]+[\\W]+[\\w]+)",message="{RegistrationDTO.UserName.Password.Invalid}")
	private String password;
	@NotNull(message="{RegistrationDTO.Empty_Field}")
	private String confirmPassword;
	@NotNull(message="{RegistrationDTO.Empty_Field}")
	@Email(message="{RegistrationDTO.Email.Invalid}")
	private String email;
	private Double walletAmount;
	//@NotNull(message="{RegistrationDTO.BankDetails.Empty}")
	//@Valid
	private BankAccountDTO bankAccountDTO;
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Double getWalletAmount() {
		return walletAmount;
	}
	public void setWalletAmount(Double walletAmount) {
		this.walletAmount = walletAmount;
	}
	public BankAccountDTO getBankAccountDTO() {
		return bankAccountDTO;
	}
	public void setBankAccountDTO(BankAccountDTO bankAccountDTO) {
		this.bankAccountDTO = bankAccountDTO;
	}
	
    
}
