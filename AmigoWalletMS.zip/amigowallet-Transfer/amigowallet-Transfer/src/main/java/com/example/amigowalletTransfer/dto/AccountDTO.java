package com.example.amigowalletTransfer.dto;

import lombok.Data;

@Data
public class AccountDTO {
	private Long senderPhoneNo;
    private Long phoneNo;
	private String email;
	private Long accountNumber;
	private Double amount;
	private String status;
	public Long getSenderPhoneNo() {
		return senderPhoneNo;
	}
	public void setSenderPhoneNo(Long senderPhoneNo) {
		this.senderPhoneNo = senderPhoneNo;
	}
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
