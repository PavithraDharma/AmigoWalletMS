package com.example.amigowalletTransfer.controller;

import java.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.amigowalletTransfer.dto.AccountDTO;
import com.example.amigowalletTransfer.dto.RegistrationDTO;
import com.example.amigowalletTransfer.exception.AmigoWalletException;
import com.example.amigowalletTransfer.service.PaymentService;


@RestController
@CrossOrigin
@RequestMapping("/AmigoWallet/Transfer/")
public class TransferController {

	@Autowired
	Environment environment;

	@Autowired
	PaymentService paymentService;

	@Autowired
	RestTemplate restTemplate;

	//Bank Account to Wallet
	@PutMapping("SelfTransfer/BankToWallet")
	public ResponseEntity<String> selfTransferToWallet(@RequestParam Long accountNumber,@RequestParam Double amount) throws AmigoWalletException
	{
		//loginResult();
		/*return new ResponseEntity<>("Transaction Successful on "+LocalDate.now()+"!"+environment.getProperty("API.Self.Transfer_To_Wallet_Successful")+" "
				+paymentService.selfTransferToWallet(accountNumber,amount),HttpStatus.ACCEPTED);
         */
		RegistrationDTO reg= accountNumberFound(accountNumber);
		return new ResponseEntity<>("Transaction Successful on "+LocalDate.now()+"!"+environment.getProperty("API.Self.Transfer_To_Wallet_Successful")+" "
				+paymentService.selfTransferToWallet(reg,amount),HttpStatus.ACCEPTED);
	}


	// US - 1 Self Transfer money from wallet to bank
	@PutMapping("SelfTransfer/WalletToBank")
	public ResponseEntity<String> selfTransferFromWallet(@RequestBody AccountDTO accountDTO) throws AmigoWalletException
	{
		//loginResult();
	    RegistrationDTO reg = accountFound(accountDTO.getPhoneNo());
		//return new ResponseEntity<>("Transaction Successful on "+LocalDate.now()+"!"+environment.getProperty("API.Self.Transfer_From_Wallet_Successful")+" "+paymentService.selfTransferFromWallet(accountDTO),HttpStatus.ACCEPTED);
		return new ResponseEntity<>("Transaction Successful on "+LocalDate.now()+"!"+environment.getProperty("API.Self.Transfer_From_Wallet_Successful")+" "+paymentService.selfTransferFromWallet(reg,accountDTO.getAmount()),HttpStatus.ACCEPTED);
	}

	// US - 2 Transfer money from one wallet to another
	@PutMapping("WalletTransfer")
	public ResponseEntity<String> moneyTransferToAnotherWallet(@RequestBody AccountDTO accountDTO) throws AmigoWalletException
	{
		//loginResult();
		if(accountDTO.getSenderPhoneNo().equals(accountDTO.getPhoneNo()))
			throw new AmigoWalletException("SERVICE.Trying_To_Do_Self_Transfer");
		RegistrationDTO sender = accountFound(accountDTO.getSenderPhoneNo());
		RegistrationDTO receiver = accountFound(accountDTO.getPhoneNo());
		return new ResponseEntity<>("Transaction Successful on "+LocalDate.now()+"!"+environment.getProperty("API.Self.Transfer_To_Another_Wallet_Successful")+" "+paymentService.moneyTransferToAnotherWallet(sender,receiver,accountDTO.getAmount()),HttpStatus.ACCEPTED);
	}

	//US - 3 Bill Payment
	@PutMapping("BillPayment")
	public ResponseEntity<String> billPayment(@RequestParam Long phoneNo) throws AmigoWalletException
	{
	    RegistrationDTO reg = accountFound(phoneNo);
		return new ResponseEntity<>("Transaction Successful on "+LocalDate.now()+"!"+environment.getProperty("API.Bill.Paid_Successfully")+" "+paymentService.billPayment(reg),HttpStatus.ACCEPTED);
	}

//	// Login check
//	public void loginResult() throws AmigoWalletException
//	{
//		//Boolean result = restTemplate.getForObject("http://localhost:8000/AmigoWallet/getFlag",Boolean.class);	
//		Boolean result = restTemplate.getForObject("http://UserMS/AmigoWallet/User/getFlag",Boolean.class);	
//		if(Boolean.FALSE.equals(result))
//			throw new AmigoWalletException("SERVICE.Login_Needed");
//	}
	//Finds whether account is there are not
	public RegistrationDTO accountFound(Long phoneNo)
	{
		System.out.println("account");
		//return restTemplate.getForObject("http://localhost:8000/AmigoWallet/"+phoneNo,RegistrationDTO.class);	
		return restTemplate.getForObject("http://UserMS/AmigoWallet/User/"+phoneNo,RegistrationDTO.class);	

	}
    public RegistrationDTO accountNumberFound(Long accountNumber)
    {
    	//return restTemplate.getForObject("http://localhost:8000/AmigoWallet/byAccount/"+accountNumber,RegistrationDTO.class);	
    	return restTemplate.getForObject("http://UserMS/AmigoWallet/byAccount/"+accountNumber,RegistrationDTO.class);	
    }
}



