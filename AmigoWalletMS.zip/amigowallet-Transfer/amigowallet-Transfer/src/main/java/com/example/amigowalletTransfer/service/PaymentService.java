package com.example.amigowalletTransfer.service;

import com.example.amigowalletTransfer.dto.RegistrationDTO;
import com.example.amigowalletTransfer.exception.AmigoWalletException;

public interface PaymentService {
	//Transfer Money from bank to wallet
	//public Double selfTransferToWallet(Long accountNumber,Double amount)throws AmigoWalletException;
	public Double selfTransferToWallet(RegistrationDTO registrationDTO,Double amount)throws AmigoWalletException;
//	//US-1 Transfer money from wallet to bank
//	public Double selfTransferFromWallet(AccountDTO accountDTO) throws AmigoWalletException;

	public Double selfTransferFromWallet(RegistrationDTO RegistrationDTO,Double amount) throws AmigoWalletException;
//	//US-2 Transfer money from wallet to another wallet
//	public Double moneyTransferToAnotherWallet(AccountDTO accountDTO) throws AmigoWalletException;
    
	public Double moneyTransferToAnotherWallet(RegistrationDTO sender, RegistrationDTO receiver,Double amount) throws AmigoWalletException;
//	//US-3 Pay Bills
	public Double billPayment(RegistrationDTO account) throws AmigoWalletException;
}
