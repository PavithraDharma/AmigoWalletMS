package com.example.amigowalletTransfer.dto;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import lombok.Data;

@Data
public class BankAccountDTO {
	@Pattern(regexp = "[A-Z]{4}[0-9]{7}",message="{BANKACCOUNTDTO.Ifsc.Invalid}")
	private String ifsc;
	@Min(value=1000000000L,message="{BANKACCOUNTDTO.AccountNumber.Invalid}")
	@Max(value=9999999999L,message="{BANKACCOUNTDTO.AccountNumber.Invalid}")
	private Long accountNumber;
	@Pattern(regexp = "[[A-Z][a-z]+[ ]]+",message="{BANKACCOUNTDTO.AccountHolderName.Invalid}")
	private String accountHolderName;
    @DecimalMin(value = "1.00" ,message= "{BANKACCOUNTDTO.Balance.Invalid}")
    @DecimalMax(value="1000000.99",message="{BANKACCOUNTDTO.Balance.Invalid}")
	private Double balance;
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public Long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
    

}