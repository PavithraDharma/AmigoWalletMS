package com.example.amigowalletTransfer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.amigowalletTransfer.dto.RegistrationDTO;
import com.example.amigowalletTransfer.dto.TransactionDTO;

@Service
public class TransactionsList {

	@Autowired
	RestTemplate restTemplate;

	// updates
	public void updateRegistration(RegistrationDTO registrationDTO) {
		//restTemplate.put("http://localhost:8000/AmigoWallet/update",registrationDTO);
	     restTemplate.put("http://UserMS/AmigoWallet/update",registrationDTO);

	}

	//Transactions
	public void transactionsCredit(TransactionDTO transactionDTO) {
		//restTemplate.put("http://localhost:8002/AmigoWallet/transactionsCredit", transactionDTO, void.class);
		restTemplate.put("http://HistoryMS/AmigoWallet/transactionsCredit", transactionDTO, void.class);
	}
	public void transactionsDebit(TransactionDTO transactionDTO) {
		//restTemplate.put("http://localhost:8002/AmigoWallet/transactionsDebit", transactionDTO, void.class);
		restTemplate.put("http://HistoryMS/AmigoWallet/transactionsDebit", transactionDTO, void.class);
	}
	public void transactionsFailed(TransactionDTO transactionDTO) {
		//restTemplate.put("http://localhost:8002/AmigoWallet/transactionsFailed", transactionDTO, void.class);
		restTemplate.put("http://HistoryMS/AmigoWallet/transactionsFailed", transactionDTO, void.class);

	}
}