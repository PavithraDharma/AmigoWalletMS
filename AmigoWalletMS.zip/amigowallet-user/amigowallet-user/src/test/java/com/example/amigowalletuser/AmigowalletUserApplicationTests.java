package com.example.amigowalletuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigowalletUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
