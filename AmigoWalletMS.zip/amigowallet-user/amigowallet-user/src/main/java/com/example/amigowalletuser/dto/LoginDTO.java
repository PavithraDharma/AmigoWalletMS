package com.example.amigowalletuser.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.Data;

@Data
public class LoginDTO {
	@NotNull(message="{LoginDTO.Empty_Field}")
	private Long phoneNo;
	@NotNull(message="{LoginDTO.Empty_Field}")
	@Pattern(regexp = "([\\w]+[\\W]+[\\w]+)",message="{LoginDTO.Password.Invalid}")
	private String password;
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}