package com.example.amigowalletuser.service;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.amigowalletuser.dto.LoginDTO;
import com.example.amigowalletuser.dto.RegistrationDTO;
import com.example.amigowalletuser.exception.AmigoWalletException;


public interface UserService {
	public String register(RegistrationDTO registrationDTO) throws AmigoWalletException;
	public String login(LoginDTO loginDTO) throws AmigoWalletException;
	//needed for paymentMS
	public RegistrationDTO getById(@PathVariable Long phoneNo) throws AmigoWalletException;
	public RegistrationDTO getByAccountNumber(@PathVariable Long accountNumber) throws AmigoWalletException;
	public void updateById(@RequestBody RegistrationDTO registrationDTO) throws AmigoWalletException;
}