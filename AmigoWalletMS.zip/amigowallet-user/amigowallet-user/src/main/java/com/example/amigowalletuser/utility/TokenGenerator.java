package com.example.amigowalletuser.utility;

import java.util.Date;
import java.util.Map;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class TokenGenerator {
	public static String createToken(Map<String, Object> claims, String subject) {
		return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 1800_000))
				.signWith(SignatureAlgorithm.HS256, "S3cr3t").compact();
		//return value.substring(value.length()-10);
	}
}
