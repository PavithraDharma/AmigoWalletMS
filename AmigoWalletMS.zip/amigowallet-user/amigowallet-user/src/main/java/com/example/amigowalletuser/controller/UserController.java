package com.example.amigowalletuser.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.amigowalletuser.dto.LoginDTO;
import com.example.amigowalletuser.dto.RegistrationDTO;
import com.example.amigowalletuser.exception.AmigoWalletException;
import com.example.amigowalletuser.service.EmailService;
import com.example.amigowalletuser.service.UserService;


@RestController
@CrossOrigin
@RequestMapping("/AmigoWallet/User/")
public class UserController {
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	Environment environment;

	@Autowired
	UserService userService;
	@Autowired
	EmailService emailService;

	Map<Long, Integer>  keyStore = new HashMap<>();

	@PostMapping("Register")
	public ResponseEntity<String> register(@RequestBody  RegistrationDTO registrationDTO) throws AmigoWalletException
	{
		System.out.println(registrationDTO);
		return new ResponseEntity<>(environment.getProperty("API.User.Registration_Successful")+" "
				+userService.register(registrationDTO),HttpStatus.CREATED);
	}
	@GetMapping("ViewProfile/{phoneNo}")
	public ResponseEntity<RegistrationDTO> viewProfile(@PathVariable Long phoneNo) throws AmigoWalletException
	{
		return new ResponseEntity<>(userService.getById(phoneNo),HttpStatus.CREATED);
	}

//	@PostMapping("Login")
//	public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO,@RequestHeader(value=HttpHeaders.AUTHORIZATION,required = false) String token) throws AmigoWalletException 
//	//public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO) throws AmigoWalletException 
//	{
//		System.out.println("Login");
//		String generatedToken = null;
//		//userService.login(loginDTO);
//		if(token==null) {
//			userService.login(loginDTO);
//			Map<String, Object> claims = new HashMap<>();
//			//generatedToken = TokenGenerator.createToken(claims, loginDTO.getPhoneNo().toString());
//			System.out.println(loginDTO.toString());
//			generatedToken = TokenGenerator.createToken(claims, loginDTO.toString());
//			keyStore.put(loginDTO.getPhoneNo(), generatedToken);
//			System.out.println("token:"+generatedToken);
//			return new ResponseEntity<>(generatedToken,HttpStatus.OK);
//		}
//		else {
//			
//			if(keyStore.containsKey(loginDTO.getPhoneNo())) {
//				String keyToken = keyStore.get(loginDTO.getPhoneNo());
//			if(token.split(" ")[1].equals(keyToken)) {
//				//System.out.println("env:"+environment.getProperty("API.User.Login_Successful")+loginDTO.getPhoneNo());
//				return new ResponseEntity<>(environment.getProperty("API.User.Login_Successful")+loginDTO.getPhoneNo(),HttpStatus.OK);	
//
//			}
//			else {
//				 throw new AmigoWalletException("API.Invalid_Token");
//			}
//			}
//			else
//				 throw new AmigoWalletException("API.Invalid_Token");
//		}
//	}
	@PostMapping("Login")
	public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO,@RequestHeader(value=HttpHeaders.AUTHORIZATION,required = false) Integer otp) throws AmigoWalletException 
	//public ResponseEntity<String> login(@RequestBody LoginDTO loginDTO) throws AmigoWalletException 
	{
		String email = userService.login(loginDTO);
		if(otp==null) {
		System.out.println(email);
		Integer otpGenerated=emailService.triggerMail(email);
		keyStore.put(loginDTO.getPhoneNo(), otpGenerated);
		}
		else {
			if(keyStore.get(loginDTO.getPhoneNo()) != null)
			{
				Integer otpGenerated = keyStore.get(loginDTO.getPhoneNo());
				if(Objects.equals(otp, otpGenerated))
				  return new ResponseEntity<>(environment.getProperty("API.User.Login_Successful"),HttpStatus.OK);
				else
					throw new AmigoWalletException("API.Invalid_Otp");
			}
		}
		return new ResponseEntity<>(environment.getProperty("API.Email.Sent"),HttpStatus.OK);
	}
//	@GetMapping("getFlag")
//	public Boolean loginResult()
//	{
//		return UserServiceImpl.flag;
//	}

	//needed for transfer ms
	@GetMapping("{phoneNo}")
	public RegistrationDTO getById(@PathVariable Long phoneNo) throws AmigoWalletException 
	{
		System.out.println("UserMS");
		return userService.getById(phoneNo);
	}

	@GetMapping("byAccount/{accountNumber}")
	public RegistrationDTO getByAccountNumber(@PathVariable Long accountNumber) throws AmigoWalletException 
	{
		return userService.getByAccountNumber(accountNumber);
	}

	@PutMapping("update")
	public String updateById(@RequestBody RegistrationDTO registrationDTO) throws AmigoWalletException
	{
		System.out.println(registrationDTO.toString());
		userService.updateById(registrationDTO);
		return "Update Success";
	}
}