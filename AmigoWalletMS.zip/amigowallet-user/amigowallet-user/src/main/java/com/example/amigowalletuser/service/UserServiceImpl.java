package com.example.amigowalletuser.service;

import java.util.Optional;
import javax.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.amigowalletuser.dto.BankAccountDTO;
import com.example.amigowalletuser.dto.LoginDTO;
import com.example.amigowalletuser.dto.RegistrationDTO;
import com.example.amigowalletuser.entity.BankAccount;
import com.example.amigowalletuser.entity.Registration;
import com.example.amigowalletuser.exception.AmigoWalletException;
import com.example.amigowalletuser.repository.AccountRepository;
import com.example.amigowalletuser.repository.BankAccountRepository;


@Service
@Transactional
public class UserServiceImpl implements UserService {

	@Autowired
	AccountRepository accountRepository;
	@Autowired
	BankAccountRepository bankRepository;

	@Autowired
	ModelMapper modelMapper;

//	public static Boolean flag = false;
//	public static Long loginNumber;
	@Override
	public String register(RegistrationDTO registrationDTO) throws AmigoWalletException {
		Optional<Registration> optional = accountRepository.findById(registrationDTO.getPhoneNo());
		if(optional.isPresent())
			throw new AmigoWalletException("SERVICE.User.Already_Exists");
		if(!(registrationDTO.getPassword().equals(registrationDTO.getConfirmPassword())))
			throw new AmigoWalletException("SERVICE.Account.Password.ConfirmPassword.Not_Equal");
		// dto = new UserDTO();
		Optional<BankAccount> bank = bankRepository.findById(registrationDTO.getBankAccountDTO().getAccountNumber());
		if(!(bank.get().getPhoneNo().equals(registrationDTO.getPhoneNo())) || !(registrationDTO.getBankAccountDTO().getPinNumber().equals(bank.get().getPinNumber())))
			throw new AmigoWalletException("SERVICE.Invalid_Registration");
		BankAccount b = bank.get();
		if(b.getBalance()<registrationDTO.getWalletAmount())
			throw new AmigoWalletException("SERVICE.Insufficient_Balance");
		b.setBalance(b.getBalance()-registrationDTO.getWalletAmount());
		accountRepository.save(modelMapper.map(registrationDTO,Registration.class));
		return registrationDTO.getName();
	}

	@Override
	public String login(LoginDTO loginDTO) throws AmigoWalletException {
		Optional<Registration> optional = accountRepository.findById(loginDTO.getPhoneNo());
		Registration registration = optional.orElseThrow(()->new AmigoWalletException("SERVICE.Login.Details.Not_Found"));
		if(!(registration.getPassword().equals(loginDTO.getPassword())))
			throw new AmigoWalletException("SERVICE.Password.Incorrect");
		//setFlag();
		return registration.getEmail();
	}

//	public static void setFlag()
//	{
//		flag = true;
//	}

	@Override
	public RegistrationDTO getById(Long phoneNo) throws AmigoWalletException {

		Optional<Registration> optional = accountRepository.findById(phoneNo);
		Registration account = optional.orElseThrow(()->new AmigoWalletException("SERVICE.Account.PhoneNo_NotFound"));
	    BankAccountDTO bank = modelMapper.map(account.getBankAccount(),BankAccountDTO.class);
		RegistrationDTO reg  =  modelMapper.map(account, RegistrationDTO.class);
		reg.setBankAccountDTO(bank);
		return reg;
	}

	@Override
	public RegistrationDTO getByAccountNumber(Long accountNumber) throws AmigoWalletException {
		Registration account = accountRepository.findByBankAccountAccountNumber(accountNumber);
		if(account == null)
			throw new AmigoWalletException("SERVICE.BankAccountNumber.NotFound");
	//	System.out.println("-----"+account.getBankAccount().getAccountHolderName());
		  BankAccountDTO bank = modelMapper.map(account.getBankAccount(),BankAccountDTO.class);
			RegistrationDTO reg  =  modelMapper.map(account, RegistrationDTO.class);
			reg.setBankAccountDTO(bank);
			return reg;
	}
	public void updateById(@RequestBody RegistrationDTO registrationDTO) throws AmigoWalletException{
		//System.out.println("service");
		Optional<Registration> optional = accountRepository.findById(registrationDTO.getPhoneNo());
		Registration reg = optional.get();
		if(registrationDTO.getName()!="" &&((reg.getName()!=null && !(reg.getName().equals(registrationDTO.getName()))) ||reg.getName()==null))
			reg.setName(registrationDTO.getName());
		if(registrationDTO.getPassword()!=""&&((reg.getPassword()!=null && !(reg.getPassword().equals(registrationDTO.getPassword()))) ||reg.getPassword()==null))
			reg.setPassword(registrationDTO.getPassword());
		if(registrationDTO.getEmail()!="" &&((reg.getEmail()!=null && !(reg.getEmail().equals(registrationDTO.getEmail()))) ||reg.getEmail()==null))
			reg.setEmail(registrationDTO.getEmail());
		if(registrationDTO.getBankAccountDTO().getAccountHolderName()!="" &&((reg.getBankAccount().getAccountHolderName()!=null && !(reg.getBankAccount().getAccountHolderName().equals(registrationDTO.getBankAccountDTO().getAccountHolderName()))) ||reg.getBankAccount().getAccountHolderName()==null))
			reg.getBankAccount().setAccountHolderName((registrationDTO.getBankAccountDTO().getAccountHolderName()));
		if(registrationDTO.getBankAccountDTO().getBranch()!="" && ((reg.getBankAccount().getBranch()!=null && !(reg.getBankAccount().getBranch().equals(registrationDTO.getBankAccountDTO().getBranch()))) ||reg.getBankAccount().getBranch()==null))
			reg.getBankAccount().setBranch((registrationDTO.getBankAccountDTO().getBranch()));
		if(registrationDTO.getBankAccountDTO().getIfscCode()!="" &&((reg.getBankAccount().getIfscCode()!=null && !(reg.getBankAccount().getIfscCode().equals(registrationDTO.getBankAccountDTO().getIfscCode()))) ||reg.getBankAccount().getIfscCode()==null))
			reg.getBankAccount().setIfscCode((registrationDTO.getBankAccountDTO().getIfscCode()));
		if(registrationDTO.getBankAccountDTO().getPinNumber()!=null && ((reg.getBankAccount().getPinNumber()!=null && !(reg.getBankAccount().getPinNumber().equals(registrationDTO.getBankAccountDTO().getPinNumber()))) ||reg.getBankAccount().getPinNumber()==null))
			reg.getBankAccount().setPinNumber((registrationDTO.getBankAccountDTO().getPinNumber()));
		if(registrationDTO.getBankAccountDTO().getAccountNumber()!=null && ((reg.getBankAccount().getAccountNumber()!=null && !(reg.getBankAccount().getAccountNumber().equals(registrationDTO.getBankAccountDTO().getAccountNumber()))) ||reg.getBankAccount().getAccountNumber()==null))
			reg.getBankAccount().setAccountNumber((registrationDTO.getBankAccountDTO().getAccountNumber()));
	}
}