package com.example.amigowalletuser.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.amigowalletuser.entity.BankAccount;

public interface BankAccountRepository extends CrudRepository<BankAccount, Long>{

}