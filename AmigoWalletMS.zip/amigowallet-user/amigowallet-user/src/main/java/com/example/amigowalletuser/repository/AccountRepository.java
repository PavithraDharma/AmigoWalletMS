package com.example.amigowalletuser.repository;

import org.springframework.data.repository.CrudRepository;

import com.example.amigowalletuser.entity.Registration;



public interface AccountRepository extends CrudRepository<Registration,Long> {
   Registration findByEmail(String email);
   Registration findByBankAccountAccountNumber(Long accountNumber); // fetch using foreign key
}
